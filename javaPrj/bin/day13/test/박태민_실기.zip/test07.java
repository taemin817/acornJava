package day13.test;

public class test07 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Book info1 = new Book("hpand1","해리포터와 마법사의 돌","조앤k롤링");
		
		System.out.println(info1.toString());
	}

}
