package day13.test;

public class test05 {

	public static void main(String[] args) {

		char[] mj ={'h','e','l','l','o',' ','j','a','v','a'};
		for(int i = 0; i<mj.length; i++) {
			System.out.print(mj[i]);
		}
	}


}
