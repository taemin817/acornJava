package day13.test;

import java.util.Random;

public class test06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random random = new Random();
		
		System.out.println(random.nextInt());
		
	}

		
}
