package Project;

public class now도서관 {
// 이름, 주소, 운영시간, 휴관일, 대여권수, 대여일수, 전화번호
	public void 이름() {
		System.out.println("이름 : 여의샛강도서관");
	}
	public void 주소(){
		System.out.println("주소 : 영등포구 여의대로 24");
	}
	public void 운영시간() {
		System.out.println("운영시간 : 평일 09:00~20:00\n\t주말 09:00~17:00");
	}
	public void 휴관일() {
		System.out.println("휴관일 : 매주 월요일, 법정공휴일");
	}
	public void 대여권수() {
		System.out.println("대여권수 : 개인당 최대 10권");
	}
	public void 대여일수() {
		System.out.println("대여일수 : 최대 21일, 연장불가");
	}
	public void 전화번호() {
		System.out.println("전화번호 : 02-2629-2222");
	}
}
